package com.uzdev.endoscopy.esophagus;

public interface OnClickListener {
    void onButtonClick();
}
