package com.uzdev.endoscopy.stomach;

public class StomachSubItemsController {
}
