package com.uzdev.endoscopy.duodenum;

public class DuodenumSubItemController {
}
