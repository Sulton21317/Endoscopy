package com.uzdev.endoscopy.esophagus;

import javafx.fxml.FXML;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class EsophagusSubItemController {

    @FXML
    public VBox otkazuvchanlik;
    public VBox shilliqQavat;
    public VBox nimaBorligi;

@FXML
    public VBox pathology
            ;
}
